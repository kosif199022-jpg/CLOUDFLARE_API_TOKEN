---
name: kosif-pro-images
description: Use for ANY image request — generating, editing, or writing prompts for ultra-detailed photorealistic or artistic images (ChatGPT images, Midjourney, Flux, SDXL). Triggers on /img /imgpro /edit /prompt or words like صورة, image, photo, logo, poster.
---

# IMAGE MODE
Always build the prompt with this formula (English):
[Subject + details] + [Action/pose/expression] + [Environment] + [Camera: shot, lens, aperture, angle] + [Lighting: direction, quality, color temp] + [Style & color grade] + [Quality boosters] + [Aspect ratio]
- Quality boosters: "ultra-detailed, razor-sharp focus, 8k textures, micro-details, realistic skin pores, accurate anatomy, perfect hands with five fingers, natural proportions, physically-based lighting".
- Pick the aspect ratio from the use: 16:9 cinema/YouTube, 9:16 reels/stories, 1:1 post, 4:5 Instagram, 3:2 photo.
- Character consistency: when a character repeats, create a "Character Lock" (age, face shape, eyes, hair, skin, outfit, distinctive marks) and reuse it verbatim in every prompt.
- Text in images: only if asked; short, exact spelling, in quotes. Arabic text: warn it may render imperfectly and offer to add it as a separate layer.
- After generating: show the final prompt in a code block + offer 2 variations (e.g. different lighting / angle).
- Refuse: sexual content, real private people, deceptive fakes of real public figures, copyrighted characters for commercial use.


# Image Prompt Library (Knowledge file)

## Lenses
14–24mm wide/epic landscapes · 35mm street/documentary · 50mm natural · 85mm portraits (f/1.4 bokeh) · 100mm macro · 200mm+ compressed telephoto

## Lighting presets
- Golden hour: warm low sun, long shadows, 3200K glow
- Rembrandt: 45° key, triangle of light on cheek, moody
- Cinematic teal-orange: warm key, cool fill, high contrast
- Softbox studio: large diffused key, clean white fill, no harsh shadows
- Neon noir: magenta & cyan practicals, wet reflective streets, fog
- Blue hour: cool ambient twilight, city lights glowing
- Volumetric: god rays through haze/dust

## Styles
Photorealistic (shot on Sony A7R V / ARRI Alexa 35) · Kodak Portra 400 film · Cinematic anamorphic · Pixar-style 3D · Studio Ghibli–inspired watercolor · Oil painting · Isometric 3D · Minimal flat vector · Luxury product commercial

## Templates
Portrait:
"Hyper-realistic portrait of [person], [expression], [outfit], [background], 85mm f/1.4, eye-level, Rembrandt lighting, shallow depth of field, natural skin texture with pores, ultra-detailed, 8k, 4:5"

Product:
"Luxury commercial photo of [product] on [surface], [props], softbox studio lighting with rim light, crisp reflections, 100mm macro, ultra-sharp, clean background [color], 1:1"

Landscape:
"Epic landscape of [place], [time/weather], 16mm wide, leading lines, volumetric light, rich dynamic range, ultra-detailed, 16:9"

Cinematic scene:
"Cinematic still of [character lock] [action] in [environment], anamorphic 35mm, [lighting preset], film grain, teal-orange grade, depth, 2.39:1"

Logo:
"Minimal modern logo for [brand], [symbol idea], flat vector, [2 colors], white background, centered, no extra text"

## Negative ideas (describe what to avoid)
blurry, low-res, extra fingers, deformed hands, distorted face, watermark, oversaturated, plastic skin, duplicate subjects, cropped head

## Character Lock template
NAME: · Age: · Ethnicity/skin: · Face shape: · Eyes: · Hair: · Build/height: · Signature outfit: · Distinctive marks: · Must never change:

## Extra commands
/style <image> → extract the style (palette HEX, lighting, lens, grade, texture) into a reusable "Style Lock" block to apply to new images.
Before generating, apply the Lighting Director presets when light matters, and after generating run a quick self-check: hands, eyes, text, anatomy, perspective; regenerate or fix if broken.
